/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backend;

import java.util.ArrayList;
import java.util.List;

public class Desenvolvedor extends Usuario {
    private String website = "";
    private String descricao = "";
    //public List<Jogo> jogosCriados;

    //Construtores
    public Desenvolvedor() {
        //this.jogosCriados = new ArrayList<>();
    }
    
    public Desenvolvedor(String nomeUsuario, String email, String senha){
        super(nomeUsuario, email, senha);
        //this.jogosCriados = new ArrayList<>();
    }

    // Getters e Setters
    public String getWebsite() {
        return this.website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getDescricao() {
        return this.descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /*
    public List<Jogo> getJogosCriados() {
        return this.jogosCriados;
    }
    
    public void setJogosCriados(List<Jogo> jogosCriados) {
        this.jogosCriados = jogosCriados;
    }
    
    // Função que adiciona jogo a lista de jogos do desenvolvedor
    public void adicionaJogo(String nome, int id, double preco, int versao, String genero, String requisitos, Desenvolvedor d){
        Jogo jogo = new Jogo(nome, id, preco, versao, genero, requisitos);
        d.getJogosCriados().add(jogo);
    }
    // Função que exclui jogo por ID ou pela classe jogo
    public void excluirJogo(int id){
        this.jogosCriados.remove(id);
    }
    
    public void excluirJogo(Jogo jogo){
        this.jogosCriados.remove(jogo);
    }
    
    public static void alteraLista(Desenvolvedor d, Jogo j){
        d.jogosCriados.add(j);
    }
    
    // Função para adicionar dados no banco de dados
    @Override
    public String toString(){
        
        String jogos = "";
        for (Jogo j:this.jogosCriados){
            jogos = "|" + j.getNome();
        }
        return super.toString() + "|" + this.website + "|" + this.descricao + jogos;
    }
    */
    @Override
    public String toString(){
        return super.toString() + "|" + this.website + "|" + this.descricao;
    }
}
